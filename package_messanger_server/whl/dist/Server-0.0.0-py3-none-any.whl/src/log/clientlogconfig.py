from serverlogconfig import logger

if __name__ == "__main__":
    logger.info("Клиентский модуль логов")
